# AppForge Assets

This folder contains all the extracted brand assets for the AppForge project, organized for easy integration into a web application.

## 📁 Folder Structure

```
appforge_assets/
├── background/           # Place your background images here
├── public/               # Static assets served at root
│   ├── apple-touch-icon.png    # 180x180 iOS home screen icon
│   ├── favicon.ico              # Multi-size favicon (16, 32, 48px)
│   ├── favicon-16x16.png        # 16x16 browser favicon
│   ├── favicon-32x32.png        # 32x32 browser favicon
│   ├── icon-192.png             # 192x192 PWA icon
│   └── icon-512.png             # 512x512 PWA icon
└── src/
    └── assets/
        ├── icons/
        │   └── app-icon.png     # 512x512 app icon (icon only)
        └── images/
            ├── logo.png         # 768x194 full logo with text
            └── logo-small.png   # 384x97 smaller logo for headers
```

## 🚀 Usage

### For React/Vite Projects

Copy the folders to your project root:

```bash
# Copy public assets
cp -r public/* /your-project/public/

# Copy src assets
cp -r src/assets/* /your-project/src/assets/
```

### HTML Head Tags

```html
<!-- Favicons -->
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">

<!-- Apple Touch Icon -->
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">

<!-- PWA Manifest Icons -->
<link rel="manifest" href="/manifest.json">
```

### PWA Manifest (manifest.json)

```json
{
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

### Using Logo in Components

```jsx
// Full logo
import logo from './assets/images/logo.png';

// Small logo for header
import logoSmall from './assets/images/logo-small.png';

// App icon only
import appIcon from './assets/icons/app-icon.png';
```

## 📋 Asset Summary

| Asset | Size | Format | Purpose |
|-------|------|--------|---------|
| favicon.ico | 16/32/48px | ICO | Browser tab icon |
| favicon-16x16.png | 16x16 | PNG | Browser favicon |
| favicon-32x32.png | 32x32 | PNG | Browser favicon |
| apple-touch-icon.png | 180x180 | PNG | iOS home screen |
| icon-192.png | 192x192 | PNG | PWA icon |
| icon-512.png | 512x512 | PNG | PWA splash screen |
| logo.png | 768x194 | PNG | Full brand logo |
| logo-small.png | 384x97 | PNG | Header/navbar logo |
| app-icon.png | 512x512 | PNG | Icon without text |

## 📝 Notes

- The `background/` folder is empty - place your background images there
- All PNGs have transparent backgrounds where applicable
- The favicon.ico contains multiple sizes for browser compatibility
